require('dotenv').config();
const { Pinecone } = require('@pinecone-database/pinecone');
const OpenAI = require('openai');
const fs = require('fs');
const csv = require('csv-parser');

const PINECONE_API_KEY = process.env.PINECONE_API_KEY;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const INDEX_NAME = 'historic-tickets';

async function main() {
  if (!PINECONE_API_KEY || !OPENAI_API_KEY) {
    console.warn("API keys not found in .env. Please set PINECONE_API_KEY and OPENAI_API_KEY to run this script.");
    return;
  }

  const pc = new Pinecone({ apiKey: PINECONE_API_KEY });
  const openai = new OpenAI({ apiKey: OPENAI_API_KEY });

  // PRJ-6111-0045: Create Pinecone Index
  console.log(`Checking if index '${INDEX_NAME}' exists...`);
  const existingIndexes = await pc.listIndexes();
  const indexExists = existingIndexes.indexes.some(idx => idx.name === INDEX_NAME);

  if (!indexExists) {
    console.log(`Creating index '${INDEX_NAME}'...`);
    await pc.createIndex({
      name: INDEX_NAME,
      dimension: 1536, // text-embedding-3-small / text-embedding-ada-002
      metric: 'cosine',
      spec: { 
        serverless: { 
          cloud: 'aws', 
          region: 'us-east-1' 
        } 
      }
    });
    console.log('Index created successfully. Waiting a moment for it to initialize...');
    await new Promise(resolve => setTimeout(resolve, 5000));
  } else {
    console.log(`Index '${INDEX_NAME}' already exists.`);
  }

  const index = pc.index(INDEX_NAME);

  // PRJ-6111-0046: Embed Historic Tickets
  console.log('Reading historic tickets from CSV...');
  const tickets = [];
  await new Promise((resolve, reject) => {
    fs.createReadStream('./tickets.csv')
      .pipe(csv())
      .on('data', (row) => tickets.push(row))
      .on('end', () => resolve())
      .on('error', reject);
  });

  console.log(`Extracted ${tickets.length} tickets. Generating embeddings...`);
  const vectors = [];
  
  for (const ticket of tickets) {
    const response = await openai.embeddings.create({
      model: "text-embedding-3-small",
      input: ticket.text,
    });
    
    vectors.push({
      id: `ticket-${ticket.id}`,
      values: response.data[0].embedding,
      metadata: { 
        text: ticket.text,
        urgency: ticket.urgency
      }
    });
  }

  console.log('Uploading vectors to Pinecone...');
  await index.upsert(vectors);
  console.log('Vectors uploaded successfully.');

  // PRJ-6111-0047: Test Index Query
  console.log('Running test query...');
  const queryText = "I need a refund for my order";
  console.log(`Querying for: "${queryText}"`);
  
  const queryResponse = await openai.embeddings.create({
    model: "text-embedding-3-small",
    input: queryText,
  });

  const queryEmbedding = queryResponse.data[0].embedding;

  const results = await index.query({
    vector: queryEmbedding,
    topK: 2,
    includeMetadata: true
  });

  console.log('Query Results:');
  results.matches.forEach((match, i) => {
    console.log(`${i + 1}. ID: ${match.id}, Score: ${match.score.toFixed(4)}`);
    console.log(`   Text: ${match.metadata.text}`);
  });
}

main().catch(console.error);
