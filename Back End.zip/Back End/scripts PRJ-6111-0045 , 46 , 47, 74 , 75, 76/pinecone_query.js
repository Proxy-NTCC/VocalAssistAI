require('dotenv').config();
const { Pinecone } = require('@pinecone-database/pinecone');
const OpenAI = require('openai');

const PINECONE_API_KEY = process.env.PINECONE_API_KEY;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const INDEX_NAME = 'historic-tickets';

/**
 * Searches Pinecone for similar historic tickets with robust error handling.
 * 
 * @param {string} queryText - The support ticket text to search for.
 * @returns {Promise<Array>} Array of similar tickets or empty array on failure/no results.
 */
async function searchSimilarTickets(queryText) {
  // PRJ-6111-0074: Add Try/Catch Logic
  try {
    if (!PINECONE_API_KEY || !OPENAI_API_KEY) {
      throw new Error("Missing API keys for Pinecone or OpenAI.");
    }

    const pc = new Pinecone({ apiKey: PINECONE_API_KEY });
    const openai = new OpenAI({ apiKey: OPENAI_API_KEY, timeout: 10000 }); // 10s timeout

    console.log(`Generating embedding for query: "${queryText}"`);
    const queryResponse = await openai.embeddings.create({
      model: "text-embedding-3-small",
      input: queryText,
    });

    if (!queryResponse?.data?.[0]?.embedding) {
      throw new Error("Invalid response from OpenAI: Missing embeddings.");
    }
    const queryEmbedding = queryResponse.data[0].embedding;

    const index = pc.index(INDEX_NAME);

    console.log('Querying Pinecone index...');
    // Pinecone query with potential timeout/network failure
    const results = await index.query({
      vector: queryEmbedding,
      topK: 3,
      includeMetadata: true
    });

    if (!results || !results.matches || results.matches.length === 0) {
      // PRJ-6111-0076: Define Fallback Path (No results found)
      console.warn("No historic tickets found matching the query. Proceeding with fallback path (empty references).");
      return [];
    }

    return results.matches;

  } catch (error) {
    // PRJ-6111-0075: Log and Notify Errors
    console.error("ERROR: Pinecone search failed.");
    console.error(`Reason: ${error.message}`);
    
    // Notify agent/system (simulated)
    notifyAgentSystem(error);

    // PRJ-6111-0076: Define Fallback Path (API failure)
    // Return empty array so the workflow continues gracefully without historic references
    console.warn("Proceeding with fallback path due to API failure. Historic context will be omitted.");
    return [];
  }
}

function notifyAgentSystem(error) {
  // This function would send an alert to a monitoring channel (Slack, DataDog, etc.)
  // or notify the AI agent orchestrator that context retrieval failed.
  console.log(`[ALERT NOTIFICATION SENT] Retrieval failure: ${error.message}`);
}

// Example usage
if (require.main === module) {
  searchSimilarTickets("I cannot login to my account").then(results => {
    if (results.length > 0) {
      console.log("Successfully retrieved similar tickets:");
      results.forEach(m => console.log(` - ID: ${m.id}, Score: ${m.score.toFixed(4)}, Text: ${m.metadata.text}`));
    } else {
      console.log("Completed with 0 results (Fallback triggered).");
    }
  });
}

module.exports = { searchSimilarTickets };
